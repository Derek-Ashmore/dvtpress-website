package j2ee.architect.handbook.common;

import org.apache.commons.lang3.exception.ContextedException;

public class BusinessProcessingException extends ContextedException {

    private static final long serialVersionUID = -8120879348588470956L;

    public BusinessProcessingException() {
        // TODO Auto-generated constructor stub
    }

    public BusinessProcessingException(String message) {
        super(message);
        // TODO Auto-generated constructor stub
    }

}

package j2ee.architect.handbook.chap11.stubs;

/**
 * Stubbed out for example
 * @author D. Ashmore
 *
 */
public class AccountEntity {
    
    boolean active;

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

}

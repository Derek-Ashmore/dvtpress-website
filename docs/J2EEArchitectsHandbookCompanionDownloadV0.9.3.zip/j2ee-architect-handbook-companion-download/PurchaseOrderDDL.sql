create table purchase_order
( order_nbr         numeric not null primary key,
  customer_id	    varchar2(20),
  date_shipped	    date,
  date_created      date
);


create table purchase_order_ln
( order_nbr         numeric not null,
  line_nbr          numeric not null,
  ITEM_ID	    varchar2(20),
  PRICE  	    numeric,
  QTY_ORDERED       numeric
);

alter table purchase_order_ln
  add primary key (order_nbr, line_nbr);
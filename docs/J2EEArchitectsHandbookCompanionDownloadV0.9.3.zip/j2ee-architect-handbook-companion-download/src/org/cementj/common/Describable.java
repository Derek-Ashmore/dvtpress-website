package org.cementj.common;

/**
 * Specification for making objects capable of providing description and state information.
 *
 * <p>Copyright:  Delta Vortex Technologies, 2001.
 */
public interface Describable {

  /**
   * Provides a textual version of description and state.
   * @since 0.5
   */
  public String describe();

}
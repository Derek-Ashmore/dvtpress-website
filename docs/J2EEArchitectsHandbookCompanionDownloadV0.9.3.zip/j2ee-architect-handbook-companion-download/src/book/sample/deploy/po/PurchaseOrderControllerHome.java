package book.sample.deploy.po;

import javax.ejb.EJBHome;
import javax.ejb.CreateException;
import java.rmi.RemoteException;

public interface PurchaseOrderControllerHome extends EJBHome
{
  public PurchaseOrderController create()
	 throws CreateException, RemoteException;
}
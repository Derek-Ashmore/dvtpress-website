package book.sample.deploy.po;

import book.sample.bo.InsufficientCreditException;
import book.sample.vo.PurchaseOrderVO;
import org.cementj.base.InternalApplicationException;

import javax.ejb.EJBObject;

public interface PurchaseOrderController extends EJBObject
{
    public void recordPurchaseOrder(PurchaseOrderVO order)
	 throws InsufficientCreditException, InternalApplicationException;
	public PurchaseOrderVO[] getPOsForCustomer (
			String customerId)
	 throws InternalApplicationException;
}
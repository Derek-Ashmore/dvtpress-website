package book.sample.deploy.po;

import book.sample.bo.PurchaseOrder;
import book.sample.bo.InsufficientCreditException;
import book.sample.vo.PurchaseOrderVO;

import org.cementj.base.DefaultSessionBean;
import org.cementj.base.InternalApplicationException;
import org.cementj.base.trans.J2EETransactionContext;
import org.cementj.log.LogManager;

public class PurchaseOrderBean 
	extends DefaultSessionBean
{
  public PurchaseOrderBean() {}

  public void recordPurchaseOrder(PurchaseOrderVO poVO)
	 throws 	InsufficientCreditException, 
	 			InternalApplicationException
  {
    try
    {
      J2EETransactionContext context =
         new J2EETransactionContext(
         	this._sessionContext);
      PurchaseOrder po = new PurchaseOrder( context, 
      										poVO);
      po.record();
    }
    catch (InsufficientCreditException ice)    
    {
    	throw ice;
    }
    catch (InternalApplicationException iae)
    {
      LogManager.getLogger().logError(iae.getMessage(), 
      								  iae);
      throw iae;
    }
    catch (Throwable t)
    {
      StringBuffer message = new StringBuffer();
      message.append("Error recording PO ==> ");
      if (poVO != null) 
      {
      	message.append(poVO.describe());
      } 
      else message.append("null");

      LogManager.getLogger().logError(
      	message.toString(), t);
      throw new InternalApplicationException
	        ( message.toString(), t);
    }
  }
  
  public PurchaseOrderVO[] getPOsForCustomer (
		String customerId)
  {
	PurchaseOrderVO[] poVO = null;
	
	try
	{
	  J2EETransactionContext context =
		 new J2EETransactionContext(this._sessionContext);
	  PurchaseOrder po = new PurchaseOrder(context);
	  //poVO = po.getPOsForCustomer(customerId);
	}
	catch (InsufficientCreditException ice)    {throw ice;}
	catch (InternalApplicationException iae)
	{
	  LogManager.getLogger().logError(iae.getMessage(), iae);
	  throw iae;
	}
	catch (Throwable t)
	{
	  StringBuffer message = new StringBuffer();
	  message.append("Error searching cust POs ==> ");
	  if (customerId != null) message.append(customerId);
	  else message.append("null");

	  LogManager.getLogger().logError(message.toString(), t);
	  throw new InternalApplicationException
			( message.toString(), t);
	}
	
	return poVO;
  }
}
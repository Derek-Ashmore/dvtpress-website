/*
 * Property of Delta Vortex Technologies, Inc.
 * 
 * Copyright 2003, All rights reserved.  
 * Use is subject to license terms.
 */
package book.sample.deploy.poweb;

import book.sample.vo.PurchaseOrderVO;

import org.apache.axis.AxisFault; 

/**
 * @author Derek C. Ashmore
 *
 */
public class POService 
{
	public void recordPurchaseOrder(PurchaseOrderVO order)
		 throws java.rmi.RemoteException
	{
		throw new AxisFault (
		    "Sorry -- your order exceeds your available credit of $"
		      + "427.35!");
	}
}

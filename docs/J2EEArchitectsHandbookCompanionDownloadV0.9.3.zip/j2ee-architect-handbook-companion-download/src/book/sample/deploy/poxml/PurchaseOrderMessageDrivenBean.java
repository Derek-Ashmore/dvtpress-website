package book.sample.deploy.poxml;

import book.sample.bo.PurchaseOrder;
import book.sample.bo.InsufficientCreditException;
import book.sample.vo.PurchaseOrderVO;
import book.sample.dao.xml.po.CustomerOrderList;

import org.cementj.base.DefaultMessageDrivenBean;
import org.cementj.base.InternalApplicationException;
import org.cementj.util.JAXBUtility;
import org.cementj.util.JMSUtility;
import org.cementj.log.LogManager;
import org.cementj.base.trans.J2EETransactionContext;

import javax.jms.TextMessage;
import javax.jms.Message;
import java.io.ByteArrayInputStream;

public class PurchaseOrderMessageDrivenBean 
	extends DefaultMessageDrivenBean
{

  public PurchaseOrderMessageDrivenBean() {}

  public void onMessage(Message message)
  {
    String xmlText = null;
    PurchaseOrderVO order = null;

    try
    {
      J2EETransactionContext context =
         new J2EETransactionContext(
         	this._messageDrivenContext);
      if (	message != null && 
      		message instanceof TextMessage)
      {
		TextMessage tm = (TextMessage) message;
		xmlText = tm.getText();
      }
      else
      {
		LogManager.getLogger().logError
	  		("Null or invalid message received by " + 
			 "PurchaseOrderMessageDrivenBean");
      }

      order = this.customerOrderListXlator(xmlText);

      PurchaseOrder po = new PurchaseOrder(	context, 
      										order);
      po.record();
    }
    catch (InsufficientCreditException ice)
    {
      LogManager.getLogger().logInfo(ice.getMessage(), 
      								 ice);
    }
    catch (InternalApplicationException iae)
    {
      LogManager.getLogger().logError(iae.getMessage(), 
      								  iae);
    }
    catch (Throwable t)
    {
      StringBuffer errMessage = new StringBuffer();
      errMessage.append("Error recording PO ==> ");
      if (order != null) 
      {
      	errMessage.append(order.describe());
      } 
      else errMessage.append("null");

      LogManager.getLogger().logError(
      	errMessage.toString(), t);
    }
    finally
    {
      JMSUtility.acknowledgeMessage(message);
    }
  }

  private PurchaseOrderVO customerOrderListXlator(String xmlText) throws Throwable
  {
    PurchaseOrderVO order = null;

    ByteArrayInputStream xmlByteStream =
        new ByteArrayInputStream(xmlText.getBytes());
      CustomerOrderList orderList = (CustomerOrderList)
        JAXBUtility.getJaxbXmlObject( "book.sample.dao.xml.po",
				      xmlByteStream);

    return order;
  }
}
package book.sample.usage;

import book.sample.vo.PurchaseOrderVO;
import org.cementj.log.LogManager;

public class DescribableExampleCode
{

  public DescribableExampleCode() {}

  public void processOrderWithDescribe(PurchaseOrderVO order)
  {
    if (order == null)
       throw new IllegalArgumentException ("Null order not allowed.");
    try
    {
      //  App code here
    }
    catch (Throwable t)
    {
      LogManager.getLogger().logError ("Error processing order: " + order.describe(), t);
    }
  }

  public void processOrderWithoutDescribe(PurchaseOrderVO order)
  {
    if (order == null)
       throw new IllegalArgumentException ("Null order not allowed.");
    try
    {
      //  App code here
    }
    catch (Throwable t)
    {
      StringBuffer errorMessage = new StringBuffer(256);
      errorMessage.append("Error processing order: ");

      errorMessage.append("custId=");
      if (order.getCustomerId() != null) errorMessage.append(order.getCustomerId());
      else errorMessage.append("null");

      errorMessage.append(", shipDt=");
      if (order.getShipDate() != null) errorMessage.append(order.getShipDate());
      else errorMessage.append("null");

      // Replicate for each field of "order".....

      LogManager.getLogger().logError ( errorMessage.toString(), t);
    }
  }
}
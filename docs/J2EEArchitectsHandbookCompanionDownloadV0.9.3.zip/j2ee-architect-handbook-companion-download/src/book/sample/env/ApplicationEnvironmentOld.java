package book.sample.env;

public class ApplicationEnvironmentOld {

  public ApplicationEnvironmentOld() {}

  public static String getDatabaseConnectionPoolName()     {return "poolName";}
}
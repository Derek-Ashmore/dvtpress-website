package book.sample.env;

import org.cementj.base.ApplicationRuntimeException;

public class SampleException extends ApplicationRuntimeException
{
  protected SampleException()    {}
  public SampleException(String message)      {super(message);}
  public SampleException(String message, Throwable t)      {super(message, t);}
}
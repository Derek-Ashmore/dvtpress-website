package book.sample.env;

import org.cementj.base.ApplicationEnvironment;

/**
 * This class is responsible for reading all
 * configuration properties for the application.
 *
 * @author Derek C. Ashmore
 */
public class SampleEnvironment 
	extends ApplicationEnvironment
{
	protected SampleEnvironment(){}

	protected String getConfigurationFileName()  
		{return CONFIG_FILE_NAME;}
	private static final SampleEnvironment 
		_myEnvironment = new SampleEnvironment();

	/**
	 * Returns Database hostname.  Default value is null.
	 * @return hostname
	 */
	public static String getDatabaseConnectionPoolName()
	{
		return _myEnvironment.getProperty("db.pool");
	}

	public static final String     CONFIG_FILE_NAME 
								= "myapp.properties";
}

/*
 * Property of Delta Vortex Technologies, Inc.
 * 
 * Copyright 2003, All rights reserved.  
 * Use is subject to license terms.
 */
package book.sample.client.web;

import book.sample.vo.PurchaseOrderVO;
import book.sample.bo.InsufficientCreditException;
import org.cementj.base.InternalApplicationException;

import org.apache.axis.client.Service;
import javax.xml.rpc.Call;
import javax.xml.rpc.ServiceException;
import javax.xml.namespace.QName;
import java.rmi.RemoteException;

/**
 * @author Derek C. Ashmore
 */
public class PoClient 
{
	public PoClient() throws ServiceException
	{
	  _webService = new Service();
	  _webServiceCall = _webService.createCall();
		  
	  _webServiceCall.setTargetEndpointAddress(
	  	PO_SERVICE_URL);
	}
	
	public void recordPurchaseOrder(
		 PurchaseOrderVO order)
		 throws 	InsufficientCreditException, 
		 			InternalApplicationException, 
		 			RemoteException
	{
		QName recordPOQName = 
			new QName("recordPurchaseOrder");

		Object[] args = new Object[1];
		args[0] = order.describeAsXMLDocument();
		_webServiceCall.setOperationName(
			recordPOQName);
		
		Object ret = null;
		ret = _webServiceCall.invoke(args);
	}
	
	public static void main(String[] arg)
	{
		try
		{
			PurchaseOrderVO order = new PurchaseOrderVO();
			order.setCustomerId("Ashmore");
			order.setOrderNbr(1);
			
		    PoClient client = new PoClient();
		    client.recordPurchaseOrder(order);	
		}
		catch (Throwable t)
		{
			t.printStackTrace();
		}
	}
	
	private Call                _webServiceCall = null;
	private Service  			_webService = null;
	
    private static final String PO_SERVICE_URL="http://localhost:8080/axis/POService.jws";
}

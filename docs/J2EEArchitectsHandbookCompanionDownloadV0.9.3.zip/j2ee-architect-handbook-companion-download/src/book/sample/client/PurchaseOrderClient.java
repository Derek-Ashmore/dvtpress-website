package book.sample.client;

import book.sample.bo.InsufficientCreditException;
import book.sample.vo.PurchaseOrderVO;
import org.cementj.base.InternalApplicationException;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
import javax.ejb.CreateException;

import book.sample.deploy.po.PurchaseOrderController;
import book.sample.deploy.po.PurchaseOrderControllerHome;

public class PurchaseOrderClient
{
  public PurchaseOrderClient() throws NamingException,
				      CreateException,
				      RemoteException
  {
    _controller = this.getController();
  }

  public void recordPurchaseOrder(PurchaseOrderVO po)
	 throws InsufficientCreditException,
		InternalApplicationException,
		RemoteException
  {
    _controller.recordPurchaseOrder(po);
  }
  
  public PurchaseOrderVO[] getPOsForCustomer (
		  String customerId)
	throws InternalApplicationException,
		   RemoteException
  {
  	return _controller.getPOsForCustomer(customerId);
  }

  private PurchaseOrderController getController()
	  throws 	NamingException, 
	  			CreateException, 
	  			RemoteException
  {
    PurchaseOrderController controller = null;
    Context ctx = new InitialContext();

    Object home = 
    	ctx.lookup("PurchaseOrderControllerHome");
    PurchaseOrderControllerHome controllerHome = 
    	(PurchaseOrderControllerHome)
      		PortableRemoteObject.narrow(home, 
      			PurchaseOrderControllerHome.class);
    controller = (PurchaseOrderController)
    	PortableRemoteObject.narrow (
            controllerHome.create(),
		    PurchaseOrderController.class);

    return controller;
  }

  private PurchaseOrderController _controller = null;
}
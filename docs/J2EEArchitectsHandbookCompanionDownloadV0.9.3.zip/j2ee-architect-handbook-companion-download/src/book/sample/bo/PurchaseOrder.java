package book.sample.bo;

import book.sample.vo.PurchaseOrderVO;
import book.sample.dao.db.PurchaseOrderDAO;
import org.cementj.base.BusinessLogicObject;
import org.cementj.base.InternalApplicationException;
import org.cementj.base.trans.TransactionContext;

import java.sql.Connection;

public class PurchaseOrder 
	extends BusinessLogicObject
{
	
  private PurchaseOrderVO   _purchaseOrderVO = null;

  protected PurchaseOrder() {}
  public PurchaseOrder(TransactionContext context) 
  {
  	super(context);
  }
  public PurchaseOrder(	TransactionContext context,
  						PurchaseOrderVO po) 
  {
  	this(context);
  	this.setPurchaseOrderVO(po);
  }

  public void record()
	 throws 	InsufficientCreditException, 
	 			InternalApplicationException
  {
    if (_purchaseOrderVO == null)
       throw new IllegalArgumentException(
			"Null orders not allowed.");

    try
    {
      this._transactionContext.begin();
      Connection conn = 
      	this._transactionContext.getConnection(
			"MyDbPoolName");
      CreditValidationBO creditBO = 
      	new CreditValidationBO(
      		this._transactionContext);
      double availableCredit =
	     creditBO.getAvailableCredit(
		_purchaseOrderVO.getCustomerId());

      if ( 	_purchaseOrderVO.getTotalOrderAmount() > 
      		availableCredit)
      {
	throw new InsufficientCreditException
	  (	"Sorry -- your order exceeds your available" + 
		" credit of $" + availableCredit + "!");
      }

      PurchaseOrderDAO orderDAO = 
      	new PurchaseOrderDAO(conn);
      orderDAO.savePurchaseOrder(_purchaseOrderVO);
      this._transactionContext.commitAll();
    }
    catch (InsufficientCreditException i)
    {
      this._transactionContext.rollbackAll();
      throw i;
    }
    catch (InternalApplicationException iae)
    {
      this._transactionContext.rollbackAll();
      throw iae;
    }
    catch (Throwable t)
    {
      this._transactionContext.rollbackAll();
      throw new InternalApplicationException
	        ( "Error recording PO ==> " + 
			  _purchaseOrderVO.describe(), t);
    }
    finally {this._transactionContext.closeAll();}
  }
  
/**
 * @return
 */
public PurchaseOrderVO getPurchaseOrderVO()
{
	return _purchaseOrderVO;
}

/**
 * @param orderVO
 */
public void setPurchaseOrderVO(PurchaseOrderVO orderVO)
{
	_purchaseOrderVO = orderVO;
}

}
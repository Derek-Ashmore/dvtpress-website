package book.sample.bo;

import org.cementj.base.BusinessLogicObject;
import org.cementj.base.trans.TransactionContext;

public class CreditValidationBO extends BusinessLogicObject {

  protected CreditValidationBO() {}
  public CreditValidationBO(TransactionContext context) {super(context);}

  public double getAvailableCredit(String customerId)
  {
    return 25000.0;
  }
}
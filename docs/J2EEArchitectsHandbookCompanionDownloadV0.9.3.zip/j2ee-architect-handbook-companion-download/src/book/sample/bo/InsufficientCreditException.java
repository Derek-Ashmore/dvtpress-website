package book.sample.bo;

import org.cementj.base.ApplicationRuntimeException;

public class InsufficientCreditException extends ApplicationRuntimeException {

  protected InsufficientCreditException() {}
  public InsufficientCreditException(String message) {super(message);}
}
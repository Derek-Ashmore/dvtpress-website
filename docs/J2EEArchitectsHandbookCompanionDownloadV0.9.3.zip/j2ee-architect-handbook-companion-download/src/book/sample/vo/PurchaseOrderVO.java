package book.sample.vo;

import org.cementj.base.ValueObject;
import java.util.Date;
import java.io.Serializable;

public class PurchaseOrderVO extends ValueObject implements Serializable 
{

  public PurchaseOrderVO() {}

  public int getOrderNbr()               {return _orderNbr;}
  public void setOrderNbr(int nbr)       {_orderNbr = nbr;}

  public String getCustomerId()          {return _customerId;}
  public void setCustomerId(String id)
  {
    //if (id == null) throw new IllegalArgumentException("Null customer id not allowed.");
    //if (id.equals("")) throw new IllegalArgumentException("Blank customer id not allowed.");
    _customerId = id;
  }

  public Date getOrderDate()             {return _dateCreated;}
  public void setOrderDate(Date date)
  {
    //if (date == null) throw new IllegalArgumentException("Null order date not allowed.");
    _dateCreated = date;
  }

  public Date getShipDate()              {return _dateShipped;}
  public void setShipDate(Date date)
  {
    _dateShipped = date;
  }

  public OrderedItemVO[] getOrderedItems()               {return _orderedItems;}
  public void setOrderedItems(OrderedItemVO[] items)
  {
    //if (items == null) throw new IllegalArgumentException("Null item list not allowed.");
    _orderedItems = items;
  }
  public void addOrderedItem(OrderedItemVO item)
  {
    if (item == null) throw new IllegalArgumentException("Null item not allowed.");
    OrderedItemVO[] tempItemList = null;

    if (_orderedItems == null)
    {
      tempItemList = new OrderedItemVO[1];
      tempItemList[0] = item;
    }
    else
    {
      tempItemList = new OrderedItemVO[_orderedItems.length + 1];
      System.arraycopy(_orderedItems, 0, tempItemList, 0, _orderedItems.length);
      tempItemList[_orderedItems.length] = item;
    }
    _orderedItems = tempItemList;
  }

  public double getTotalOrderAmount()
  {
    double total = 0.0;

    // logic not implemented yet.

    return total;
  }

  private int               _orderNbr = 0;
  private String            _customerId = null;
  private Date              _dateCreated = null;
  private Date              _dateShipped = null;
  private OrderedItemVO[]  _orderedItems = null;
}
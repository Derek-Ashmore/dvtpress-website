package book.sample.vo.cementj;

import org.cementj.base.ValueObject;

public class CustomerVO extends ValueObject
{

  public CustomerVO() {}

  public String          getCustomerId()         
  {
  	return _customerId;
  }
  public void            setCustomerId(String id)
  {
    if (id == null)  
    {
    	throw new IllegalArgumentException
    			("Null customer Id not allowed.");
    } 
    if (id.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank customer Id not allowed.");
    } 
    _customerId = id;
  }

  public String          getFirstName()          
  {
  	return _firstName;
  }
  public void            setFirstName(String name)
  {
    if (name == null)  
    {
    	throw new IllegalArgumentException
    			("Null first name not allowed.");
    } 
    if (name.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank first name not allowed.");
    } 
    _firstName = name;
  }

  public String          getLastName()          
  {
  	return _lastName;
  }
  public void            setLastName(String name)
  {
    if (name == null)  
    {
    	throw new IllegalArgumentException
    			("Null last name not allowed.");
    } 
    if (name.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank last name not allowed.");
    } 
    _lastName = name;
  }

  public String          getAddress()           
  {
  	return _address;
  }
  public void            setAddress(String address)
  {
    if (address == null)  
    {
    	throw new IllegalArgumentException
    			("Null address not allowed.");
    } 
    if (address.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank address not allowed.");
    } 
    _address = address;
  }

  public String          getCity()              
  {
  	return _city;
  }
  public void            setCity(String city)
  {
    if (city == null)  
    {
    	throw new IllegalArgumentException
    			("Null city not allowed.");
    } 
    if (city.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank city not allowed.");
    } 
    _city = city;
  }

  public String          getState()          
  {
  	return _state;
  }
  public void            setState(String state)
  {
    if (state == null)  
    {
    	throw new IllegalArgumentException
    			("Null state not allowed.");
    } 
    if (state.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank state not allowed.");
    } 
    _state = state;
  }

  public String          getZipCode()          
  {
  	return _zipCode;
  }
  public void            setZipCode(String zipCode)
  {
    if (zipCode == null)  
    {
    	throw new IllegalArgumentException
    			("Null zipCode not allowed.");
    } 
    if (zipCode.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank zipCode not allowed.");
    } 
    _zipCode = zipCode;
  }

  private String          _customerId = null;
  private String          _firstName = null;
  private String          _lastName = null;
  private String          _address = null;
  private String          _city = null;
  private String          _state = null;
  private String          _zipCode = null;
}
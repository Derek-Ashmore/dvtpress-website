package book.sample.vo.cementj;

public class TestCustomerVO {

  public TestCustomerVO() {}

  public static void main(String[] args)
  {
    CustomerVO dto = new CustomerVO();
    dto.setCustomerId("12345");
    dto.setFirstName("Derek");
    dto.setLastName("Ashmore");
    dto.setAddress("34 Yorktown Center, PMB 400");
    dto.setCity("Lombard");
    dto.setState("IL");
    dto.setZipCode("60148");

    System.out.println(dto.describeAsXMLDocument());

    long startTime, endTime;

    startTime = System.currentTimeMillis();
    for (int i = 0; i < NBR_ITERATIONS; i++)  {dto.hashCode();}
    endTime = System.currentTimeMillis() - startTime;
    System.out.println("Hashcode time: " + endTime + " ms.");

    startTime = System.currentTimeMillis();
    for (int i = 0; i < NBR_ITERATIONS; i++)  {dto.equals(dto);}
    endTime = System.currentTimeMillis() - startTime;
    System.out.println("Equals time: " + endTime + " ms.");

    startTime = System.currentTimeMillis();
    for (int i = 0; i < NBR_ITERATIONS; i++)  {dto.compareTo(dto);}
    endTime = System.currentTimeMillis() - startTime;
    System.out.println("compareTo time: " + endTime + " ms.");

    startTime = System.currentTimeMillis();
    for (int i = 0; i < NBR_ITERATIONS; i++)  {new CustomerVO();}
    endTime = System.currentTimeMillis() - startTime;
    System.out.println("Instantiation time: " + endTime + " ms.");
  }

  public static final int NBR_ITERATIONS = 1000;
}
package book.sample.vo;

import java.io.Serializable;
import org.cementj.common.Describable;

/**
 * This is a sample Value Object definition.
 */
public class CustomerVO 
	implements Serializable, Describable
{
  public CustomerVO() {}

  public String          getCustomerId()         
  {
  	return _customerId;
  }
  public void            setCustomerId(String id)
  {
    if (id == null)  
    {
    	throw new IllegalArgumentException 
    	     ("Null customer Id not allowed.");
    } 
    if (id.equals(""))  
    {
    	throw new IllegalArgumentException
    	 	 ("Blank customer Id not allowed.");
    } 
    _customerId = id;
  }

  public String          getFirstName()          
  {
  	return _firstName;
  }
  public void            setFirstName(String name)
  {
    if (name == null)  
    {
    	throw new IllegalArgumentException
    			  ("Null first name not allowed.");
    } 
    if (name.equals(""))  
    {
    	throw new IllegalArgumentException
    			 ("Blank first name not allowed.");
    } 
    _firstName = name;
  }

  public String          getLastName()          
  {
  	return _lastName;
  }
  public void            setLastName(String name)
  {
    if (name == null)  
    {
    	throw new IllegalArgumentException
    			("Null last name not allowed.");
    } 
    if (name.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank last name not allowed.");
    }
    _lastName = name;
  }

  public String          getAddress()           
  {
  	return _address;
  }
  public void            setAddress(String address)
  {
    if (address == null)  
    {	
    	throw new IllegalArgumentException
    			("Null address not allowed.");
    } 
    if (address.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank address not allowed.");
    } 
    _address = address;
  }

  public String          getCity()              
  {
  	return _city;
  }
  public void            setCity(String city)
  {
    if (city == null)  
    {
    	throw new IllegalArgumentException
    			("Null city not allowed.");
    } 
    if (city.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank city not allowed.");
    } 
    _city = city;
  }

  public String          getState()          
  {
  	return _state;
  }
  public void            setState(String state)
  {
    if (state == null)  
    {
    	throw new IllegalArgumentException
    			("Null state not allowed.");
    } 
    if (state.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank state not allowed.");
    } 
    _state = state;
  }

  public String          getZipCode()          
  {
  	return _zipCode;
  }
  public void            setZipCode(String zipCode)
  {
    if (zipCode == null)  
    {
    	throw new IllegalArgumentException
    			("Null zipCode not allowed.");
    } 
    if (zipCode.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank zipCode not allowed.");
    } 
    _zipCode = zipCode;
  }

  public String describe()
  {
    StringBuffer buffer = new StringBuffer(512);

    buffer.append("CustomerVO==>custId=");

    if (_customerId != null) 
    {
    	buffer.append(_customerId);
    } 
    else buffer.append("null");

    buffer.append(",firstName=");
    if (_firstName != null) buffer.append(_firstName);
    else buffer.append("null");

    buffer.append(",lastName=");
    if (_lastName != null) buffer.append(_lastName);
    else buffer.append("null");

    buffer.append(",address=");
    if (_address != null) buffer.append(_address);
    else buffer.append("null");

    buffer.append(",city=");
    if (_city != null) buffer.append(_city);
    else buffer.append("null");

    buffer.append(",state=");
    if (_state != null) buffer.append(_state);
    else buffer.append("null");

    buffer.append(",zip=");
    if (_zipCode != null) buffer.append(_zipCode);
    else buffer.append("null");

    return buffer.toString();
  }

  public int hashcode()
  {
    return this.getObjectAsString().hashCode();
  }

  public boolean equals(Object obj)
  {
    boolean answer = false;

    if (obj instanceof CustomerVO)
    {
      String dtoId = 
      	this.getObjectAsString( (CustomerVO) obj );
      if (this.getObjectAsString().equals(dtoId)) 
      {
      	answer = true;
      } 
    }

    return answer;
  }

  public int compareTo(Object obj)
  {
    int compareResult = 0;
    Object tempObj = null;
    Object tempObjCompareTarget = null;
    Comparable c1, c2;

    if (obj == null)  
    {
    	throw new IllegalArgumentException
    	("Comparisons to null objects not defined.");
    } 
    if (! (obj instanceof CustomerVO) )  
    {
    	throw new IllegalArgumentException
     ("Comparing different class types not allowed.");
    } 

    CustomerVO dto = (CustomerVO) obj;
    compareResult = _lastName.compareTo(dto._lastName);
    if (compareResult == 0) 
    {
    	compareResult = 
    		_firstName.compareTo(dto._firstName);
    } 
    if (compareResult == 0) 
    {
    	compareResult = 
    		_customerId.compareTo(dto._customerId);
    } 
    if (compareResult == 0) 
    {
    	compareResult = 
    		_address.compareTo(dto._address);
    } 
    if (compareResult == 0) 
    {
    	compareResult = 
    		_city.compareTo(dto._city);
    } 
    if (compareResult == 0) 
    {	
    	compareResult = _state.compareTo(dto._state);
    } 
    if (compareResult == 0) 
    {
    	compareResult = 
    		_zipCode.compareTo(dto._zipCode);
    } 

    return compareResult;
  }

  private String getObjectAsString()
  {
    return this.getObjectAsString(this);
  }

  private String getObjectAsString(CustomerVO vo)
  {
    StringBuffer buffer = new StringBuffer(256);

    if (vo._customerId != null) 
    {
    	buffer.append(vo._customerId);
    } 
    else buffer.append("null");
    if (vo._firstName != null) 
    {
    	buffer.append(vo._firstName);
    } 
    else buffer.append("null");
    if (vo._lastName != null) 
    {
    	buffer.append(vo._lastName);
    } 
    else buffer.append("null");
    if (vo._address != null) 
    {
    	buffer.append(vo._address);
    } 
    else buffer.append("null");
    if (vo._city != null) buffer.append(vo._city);
    else buffer.append("null");
    if (vo._state != null) buffer.append(vo._state);
    else buffer.append("null");
    if (vo._zipCode != null) 
    {
    	buffer.append(vo._zipCode);
    } 
    else buffer.append("null");

    return buffer.toString();
  }

  private String          _customerId = null;
  private String          _firstName = null;
  private String          _lastName = null;
  private String          _address = null;
  private String          _city = null;
  private String          _state = null;
  private String          _zipCode = null;

}
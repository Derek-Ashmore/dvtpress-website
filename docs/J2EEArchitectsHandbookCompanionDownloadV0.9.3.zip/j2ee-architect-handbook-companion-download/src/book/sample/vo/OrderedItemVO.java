package book.sample.vo;

import org.cementj.base.ValueObject;

public class OrderedItemVO extends ValueObject
{
	private int _orderNbr         	= 0;
	private int _lineNbr		  	= 0;
	private String _itemId		  	= null;
	private int _quantityOrdered	= 0;
	private double _pricePerUnit	= 0.0;

    public OrderedItemVO() {}
    
	/**
	 * @return
	 */
	public String getItemId()
	{
		return _itemId;
	}

	/**
	 * @return
	 */
	public int getLineNbr()
	{
		return _lineNbr;
	}

	/**
	 * @return
	 */
	public int getOrderNbr()
	{
		return _orderNbr;
	}

	/**
	 * @return
	 */
	public double getPricePerUnit()
	{
		return _pricePerUnit;
	}

	/**
	 * @return
	 */
	public int getQuantityOrdered()
	{
		return _quantityOrdered;
	}

	/**
	 * @param string
	 */
	public void setItemId(String id)
	{
		_itemId = id;
	}

	/**
	 * @param i
	 */
	public void setLineNbr(int i)
	{
		_lineNbr = i;
	}

	/**
	 * @param i
	 */
	public void setOrderNbr(int i)
	{
		_orderNbr = i;
	}

	/**
	 * @param d
	 */
	public void setPricePerUnit(double d)
	{
		_pricePerUnit = d;
	}

	/**
	 * @param i
	 */
	public void setQuantityOrdered(int i)
	{
		_quantityOrdered = i;
	}

}
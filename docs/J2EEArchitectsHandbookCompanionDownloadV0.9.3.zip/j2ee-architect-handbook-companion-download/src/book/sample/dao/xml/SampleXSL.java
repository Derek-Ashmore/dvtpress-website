package book.sample.dao.xml;

import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

public class SampleXSL
{

  public SampleXSL() { }

  public String runSimpleTransformation()
	 throws TransformerConfigurationException,
		TransformerException
  {
    ByteArrayOutputStream output = 
    	new ByteArrayOutputStream (200000);
    TransformerFactory tFactory = 
    	TransformerFactory.newInstance();
    Transformer transformer = tFactory.newTransformer
		(new StreamSource("PurchaseOrder.xsl"));
    transformer.transform( 
    	new StreamSource("PurchaseOrder.xml"),
			   new StreamResult(output) );
    return output.toString();
  }

  public void timeTransformationSteps()
	 throws TransformerConfigurationException,
		TransformerException,
		FileNotFoundException
  {
    final int NBR_ITERATIONS = 1000;

    long start = System.currentTimeMillis();
    TransformerFactory tFactory = null;
    for (int i = 0 ; i < NBR_ITERATIONS; i++)  
    {tFactory = TransformerFactory.newInstance();}

    long afterFactory = System.currentTimeMillis();
    Transformer transformer = null;
    for (int i = 0 ; i < NBR_ITERATIONS; i++)
      {
      	transformer = tFactory.newTransformer (
      		new StreamSource("PurchaseOrder.xsl"));
      }

    long afterXslParse = System.currentTimeMillis();
    for (int i = 0 ; i < NBR_ITERATIONS - 1; i++)
    {transformer.transform( 
    	new StreamSource("PurchaseOrder.xml"),
			   new StreamResult
			       (new FileOutputStream (
						"PurchaseOrder.html")));}
    long afterTransformation = 
    	System.currentTimeMillis();

    System.out.println(	"Factory instantiation: " + 
    	(afterFactory - start) + " ms.");
    System.out.println(	"XSL Parse: " + 
    	(afterXslParse - afterFactory) + " ms.");
    System.out.println("Transformation: " + 
    	(afterTransformation - afterXslParse) + 
			" ms.");
  }

  public static void main(String[] args) {
    SampleXSL sampleXSL = new SampleXSL();

    try
    {
      sampleXSL.runSimpleTransformation();
      //sampleXSL.timeTransformationSteps();
    }
    catch (Throwable t)  {t.printStackTrace();}
  }
}
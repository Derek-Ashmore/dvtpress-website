package book.sample.dao.xml;

import org.cementj.util.JAXBUtility;
import book.sample.vo.PurchaseOrderVO;
import book.sample.dao.xml.po.CustomerOrderList;
import book.sample.dao.xml.po.CustomerOrderType;
import book.sample.dao.xml.po.ObjectFactory;
import book.sample.env.SampleException;

import javax.xml.bind.JAXBException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class PurchaseOrderXAO
{
  private static final String 
  	PURCHASE_ORDER_JAXB_PACKAGE = 
		"book.sample.dao.xml.po";
		
  public void setPurchaseOrder(PurchaseOrderVO[] order)
  {
	_purchaseOrder = order;
  }
  
  public void setPurchaseOrder(String xmlText)
  {
	if (xmlText == null)
	{
		throw new IllegalArgumentException(
			"Null xmlText not allowed."
			);
	}
	if (xmlText.equals(""))
	{
		throw new IllegalArgumentException(
			"Blank xmlText not allowed."
			);
	}
	ByteArrayInputStream xmlInputStream =
	  new ByteArrayInputStream(xmlText.getBytes());
	this.setPurchaseOrder(xmlInputStream);
  }
  
  public void setPurchaseOrder(InputStream xmlStream)
  {
    PurchaseOrderVO[] poArray = null;
    ArrayList poList = new ArrayList();
    PurchaseOrderVO po = null;
    CustomerOrderType xmlOrder = null;

    try
    {
      CustomerOrderList order =
        (CustomerOrderList) 
        	JAXBUtility.getJaxbXmlObject(
	     		PURCHASE_ORDER_JAXB_PACKAGE,
				xmlStream );
      List xmlOrderList = order.getCustomerOrder();
      for (int i = 0 ; i < xmlOrderList.size(); i++)
      {
		xmlOrder = (CustomerOrderType) 
						xmlOrderList.get(i);
		po = new PurchaseOrderVO();

		po.setCustomerId(xmlOrder.getCustomerId());
		po.setOrderNbr(
			Integer.parseInt( xmlOrder.getOrderId() ));
		// ... Other Purchase Order information 
		//     gathered here.

		poList.add(po);
      }

      if (poList.size() > 0)
      {
		poArray = new PurchaseOrderVO[poList.size()];
		poArray = (PurchaseOrderVO[]) 
					poList.toArray(poArray);
      }
      
	  this.setPurchaseOrder(poArray);
    }
    catch (Throwable t)
    {
      throw new SampleException(
		"Error parsing PO XML.", t);
    }
  }
  
  public PurchaseOrderVO[] getPurchaseOrder()
  {
  	return _purchaseOrder;
  }
  
  public String getPurchaseOrderXmlText()
  {
    String xmlText = null;
    ObjectFactory factory = new ObjectFactory();

    CustomerOrderType xmlOrder = null;

    try
    {
      CustomerOrderList xmlOrderList = 
      	factory.createCustomerOrderList();
      for (int i = 0; i < _purchaseOrder.length; i++)
      {
        xmlOrder = factory.createCustomerOrderType();
		xmlOrder.setCustomerId(
			_purchaseOrder[i].getCustomerId());
		xmlOrder.setOrderId(
			Integer.toString( 
				_purchaseOrder[i].getOrderNbr() ));
        // ... Other Purchase Order information set 
        //     here.

        xmlOrderList.getCustomerOrder().add(xmlOrder);
      }

      xmlText = JAXBUtility.flushXmlToString(
			PURCHASE_ORDER_JAXB_PACKAGE, xmlOrderList);
    }
    catch (JAXBException j)
    {
      throw new SampleException(
		"Error creating PO XML.", j);
    }

    return xmlText;
  }
  
  public String getPurchaseOrderAsHtml()
  {
  	String htmlText = null;
  	String xmlText = this.getPurchaseOrderXmlText();
	ByteArrayInputStream xmlTextStream = 
		new ByteArrayInputStream(xmlText.getBytes());
  	
  	try
  	{
		ByteArrayOutputStream output = 
				new ByteArrayOutputStream 
					(xmlText.length() * 2);
		TransformerFactory tFactory = 
				TransformerFactory.newInstance();
		Transformer transformer = 
			tFactory.newTransformer
			   (new StreamSource("PurchaseOrder.xsl"));
			transformer.transform( 
				new StreamSource(xmlTextStream),
			   		new StreamResult(output) );
	    htmlText = output.toString();
	}
	catch (Throwable t)
	{
		throw new SampleException(
		  "Error creating PO HTML.", t);
	}
  	
  	return htmlText;
  }
  
  private PurchaseOrderVO[]		_purchaseOrder = null;

}
package book.sample.dao.xml;

import org.cementj.util.JAXBUtility;
import book.sample.dao.xml.po.CustomerOrderList;

import java.io.InputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class SampleJAXB 
{

  public SampleJAXB() {}

  public Object getJAXBObject() throws Throwable
  {
    InputStream xmlDocumentInputStream = 
    	new FileInputStream( "PurchaseOrder.xml" );
    JAXBContext jc = JAXBContext.newInstance( 
		"book.sample.dao.xml.po" );
    Unmarshaller u = jc.createUnmarshaller();
    return u.unmarshal( xmlDocumentInputStream );
  }

  public Object getJAXBObjectViaCementJ() 
  	throws Throwable
  {
    return JAXBUtility.getJaxbXmlObject(
		"book.sample.dao.xml.po", 
		new File("PurchaseOrder.xml") );
  }

  public void serializeJAXBObject(
  		CustomerOrderList order)  
  	throws Throwable
  {
    JAXBContext jc = JAXBContext.newInstance( 
		"book.sample.dao.xml.po" );
    Marshaller m = jc.createMarshaller();
    m.setProperty( Marshaller.JAXB_FORMATTED_OUTPUT, 
    	Boolean.TRUE );
    m.marshal( order, new FileOutputStream(
		"PurchaseOrderGenerated.xml") );
  }
  
  public void serializeJAXBObjectWithCementJ(
		CustomerOrderList order)  
	throws Throwable
  {
	JAXBUtility.flushXmlToStream(
	  "book.sample.dao.xml.po", 
	  order, new FileOutputStream(
		  "PurchaseOrderGeneratedCementJ.xml"));
  }

  public static void main(String[] args) 
  {
    SampleJAXB sampleJAXB = new SampleJAXB();

    try
    {
      Object jaxbObject = sampleJAXB.getJAXBObject();
      System.out.println(jaxbObject.getClass().getName());
      CustomerOrderList order = (CustomerOrderList) 
      	JAXBUtility.getJaxbXmlObject(
			"book.sample.dao.xml.po", 
				new File("PurchaseOrder.xml") );
      System.out.println(order.getClass().getName());

      sampleJAXB.serializeJAXBObject(order);

      JAXBUtility.flushXmlToStream(
		"book.sample.dao.xml.po", 
		order, new FileOutputStream(
			"PurchaseOrderGeneratedCementJ.xml"));
    }
    catch (Throwable t)
    {
      t.printStackTrace();
    }
  }

}
package book.sample.dao.db.ejb.po;

import book.sample.vo.PurchaseOrderVO;
import java.util.Date;
import javax.ejb.*;

/**
 * The Local Interface Buisness Methods for the Purchase Order Sample.
 */

public interface PurchaseOrder extends EJBLocalObject {   

    public void setOrderNbr (int nbr); 
    public int getOrderNbr (); 

    public void setCustomerId (String id); 
    public String getCustomerId (); 

    public void setDateShipped (Date shipDate); 
    public Date getDateShipped ();
    
	public void setDateCreated (Date createDate); 
	public Date getDateCreated ();
 
    public PurchaseOrderVO makePurchaseOrderVO ();
   
}


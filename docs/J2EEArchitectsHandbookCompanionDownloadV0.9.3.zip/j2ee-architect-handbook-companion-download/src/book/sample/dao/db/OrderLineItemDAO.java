package book.sample.dao.db;

import org.cementj.base.DbDataAccessObject;

import book.sample.vo.OrderedItemVO;

import java.sql.Connection;
import java.sql.SQLException;

public class OrderLineItemDAO extends DbDataAccessObject
{
  protected OrderLineItemDAO()          {super();}
  public OrderLineItemDAO(Connection conn) throws SQLException {super(conn);}

  public OrderedItemVO[] getPOItems(int orderNbr) throws SQLException
  {
    OrderedItemVO[] lines = null;

    return lines;
  }
}
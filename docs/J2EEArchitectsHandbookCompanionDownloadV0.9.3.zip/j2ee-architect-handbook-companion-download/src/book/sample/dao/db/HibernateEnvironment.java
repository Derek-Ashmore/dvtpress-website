/*
 * Property of Delta Vortex Technologies, Inc.
 * 
 * Copyright 2003, All rights reserved.  
 * Use is subject to license terms.
 */
package book.sample.dao.db;

import book.sample.vo.*;
import book.sample.env.SampleException;

import net.sf.hibernate.SessionFactory;
import net.sf.hibernate.HibernateException;
import net.sf.hibernate.cfg.Configuration;

import java.util.Properties;

/**
 * Class to create Hibernate SessionFactory for use by 
 * data access object classes.
 * @author Derek C. Ashmore
 */
public class HibernateEnvironment
{
	private static SessionFactory _sessionFactory;
	static
	{ 
		Properties props = new Properties();
		props.put(	"hibernate.dialect", 
			"net.sf.hibernate.dialect.Oracle9Dialect");
		props.put(	
			"hibernate.cglib.use_reflection_optimizer", 
			"true");
		props.put("hibernate.connection.driver_class", 
			"oracle.jdbc.driver.OracleDriver");
		props.put("hibernate.connection.url", 
			"jdbc:oracle:thin:@localhost:1521:ORA92");
		props.put(	"hibernate.connection.username", 
					"scott");
		props.put(	"hibernate.connection.password", 
			"tiger");
		props.put(	"hibernate.connection.pool_size", 
			"3");
		props.put(	"hibernate.statement_cache.size", 
			"3");
		
		Configuration cfg = new Configuration();
		try
		{
			cfg.addClass(OrderedItemVO.class);
			cfg.addClass(PurchaseOrderVO.class);
			cfg.setProperties(props);
		
			_sessionFactory = 
				cfg.buildSessionFactory();
		}
		catch (HibernateException h)
		{
			throw new SampleException(
				"Hibernate configuration error", h);
		}
	}
	
	public static SessionFactory getSessionFactory()
	{
		return _sessionFactory;
	}
}

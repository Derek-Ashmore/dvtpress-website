package book.sample.dao.db.ejb.po;

import book.sample.vo.PurchaseOrderVO;

import java.util.Date;
import javax.ejb.*;

public abstract class PurchaseOrderBean 
	implements EntityBean 
{
    public abstract int getOrderNbr();         
    public abstract void setOrderNbr(int nbr);  

    public abstract String getCustomerId();
    public abstract void setCustomerId(String id);
    
    public abstract Date getDateCreated();
    public abstract void setDateCreated(Date d);
    
	public abstract Date getDateShipped();
	public abstract void setDateShipped(Date d);
    
    public PurchaseOrderVO makePurchaseOrderVO () 
    {
		PurchaseOrderVO vo = new PurchaseOrderVO();
		
		vo.setCustomerId(this.getCustomerId());
		vo.setOrderNbr(this.getOrderNbr());
		vo.setShipDate(this.getDateShipped());
		vo.setOrderDate(this.getDateCreated());
		
        return(vo);
    }
     
    public PurchaseOrderPK ejbCreate (
			int orderNbr, 
			String customerId, 
			Date dateCreated, 
			Date dateShipped)
        throws CreateException 
    {
        this.setOrderNbr(orderNbr);
 		this.setCustomerId(customerId);
 		this.setDateShipped(dateShipped);
 		this.setDateCreated(dateCreated);

        return null; 
    }

    public void ejbPostCreate (
    			int orderNbr, 
				String customerId, 
				Date dateCreated, 
				Date dateShipped) {}

    public void setEntityContext (EntityContext ctx){}
    public void unsetEntityContext() {}
    public void ejbLoad() {} 
    public void ejbStore() {}
    public void ejbRemove () {}
    public void ejbActivate () {}
    public void ejbPassivate () {}     
}


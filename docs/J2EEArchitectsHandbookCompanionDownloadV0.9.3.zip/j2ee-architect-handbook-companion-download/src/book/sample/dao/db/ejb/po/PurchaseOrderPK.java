package book.sample.dao.db.ejb.po;

import java.io.Serializable;

/**
 * The Primary Key Class for the CMP Purchase Order 
 * Sample.  
 */

public class PurchaseOrderPK implements Serializable 
{

    public int orderNbr;
      
    public PurchaseOrderPK () {}
   
    public PurchaseOrderPK (int orderNbr) 
    {
		this.orderNbr = orderNbr;
    }
    public int getOrderNbr () 
    {
        return orderNbr;
    }

    public int hashCode() 
    {
        return new Integer(orderNbr).hashCode();
    }

    public boolean equals(Object other) 
    {
        if ((other == null) || 
        		!(other instanceof PurchaseOrderPK)) 
        {
            return false;
        }

		PurchaseOrderPK otherPK = 
			(PurchaseOrderPK) other;

        return (orderNbr == otherPK.orderNbr);
    }
}

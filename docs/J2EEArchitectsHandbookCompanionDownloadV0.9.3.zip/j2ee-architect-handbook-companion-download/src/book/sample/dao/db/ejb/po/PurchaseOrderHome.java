package book.sample.dao.db.ejb.po;

import javax.ejb.*;
import java.util.Collection;
import java.util.Date;

/**
 * The Home Interface for the Purchase Order CMP 
 * Sample.
 */

public interface PurchaseOrderHome extends EJBLocalHome 
{ 

    public abstract PurchaseOrder create (
    		int orderNbr, 
    		String customerId, 
    		Date dateCreated, 
			Date dateShipped)
        throws CreateException; 
   
    public abstract PurchaseOrder findByPrimaryKey (
    	PurchaseOrderPK primaryKey)
        throws FinderException; 

    public abstract Collection findByCustomerId(
    	String customerId)
        throws FinderException; 
        
}


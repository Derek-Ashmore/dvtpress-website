package book.sample.dao.db;

import book.sample.vo.PurchaseOrderVO;
import book.sample.vo.OrderedItemVO;
import org.cementj.base.DbDataAccessObject;
import org.cementj.base.DataNotFoundException;
import org.cementj.util.DatabaseUtility;

import book.sample.dao.db.ejb.po.PurchaseOrder;
import book.sample.dao.db.ejb.po.PurchaseOrderHome;
import book.sample.env.SampleException;

import net.sf.hibernate.Session;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.util.Collection;
import java.util.Iterator;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PurchaseOrderDAO extends DbDataAccessObject
{
  protected PurchaseOrderDAO()          {super();}
  public PurchaseOrderDAO(Connection conn) throws SQLException {super(conn);}
  public PurchaseOrderDAO(Session session) throws SQLException 
  {
  	super();
  	this.setHibernateSession(session);
  }
  
  private Session		_hibernateSession = null;

  private static final String SELECT_SQL =
     "select CUSTOMER_ID, DATE_CREATED, DATE_SHIPPED " +
     "   from    PURCHASE_ORDER " +
     "   where   ORDER_NBR = ?";
  public PurchaseOrderVO getPurchaseOrder(int orderNbr) 
  	throws SQLException
  {
    PurchaseOrderVO order = null;

    PreparedStatement pStmt = null;
    ResultSet results = null;

    try
    {
      OrderLineItemDAO lineDAO = 
      	new OrderLineItemDAO(this._dbConnection);
      pStmt = this._dbConnection.prepareStatement(
      			SELECT_SQL);
      pStmt.setInt(1, orderNbr);

      results = pStmt.executeQuery();
      if (results.next())
      {
		order = new PurchaseOrderVO();
		order.setOrderNbr(orderNbr);
		order.setCustomerId(results.getString(
			"CUSTOMER_ID"));
		order.setOrderDate(results.getDate(
			"DATE_CREATED"));
		order.setShipDate(results.getDate(
			"DATE_SHIPPED"));
		order.setOrderedItems(
			lineDAO.getPOItems(orderNbr));
      }
      else
      {
	throw new DataNotFoundException
	     ("Purchase order not found.  OrderNbr=" + 
	     	orderNbr);
      }
    }
    finally
    {
    	// CementJ alternative for close
      	//--> DatabaseUtility.close(results, pStmt);
      	
      	if (results != null)
      	{
      		try {results.close();}
      		catch (SQLException s)
      		{
      			// Log warning here.
      		}
      	}
		if (pStmt != null)
		{
			try {pStmt.close();}
			catch (SQLException s)
			{
				// Log warning here.
			}
		}
    }

    return order;
  }

  public void savePurchaseOrder(PurchaseOrderVO order) 
  	throws SQLException
  {
    try
    {
		Integer generatedOrderNbr = 
		  (Integer) this._hibernateSession.save(order);		
			
		OrderedItemVO[] line = order.getOrderedItems();
		for (int i = 0 ; i < line.length; i++)
		{
			line[i].setOrderNbr(
				generatedOrderNbr.intValue());
			line[i].setLineNbr(i);
			this._hibernateSession.save(line[i]);
		}
    }
    catch (Throwable t)
    {
    	throw new SampleException(
			"Error saving purchase order: " + 
			order.describe(), t);
    }
  }
  
  public PurchaseOrderVO[] getPOsForCustomer (
		String customerId)
  {
	PurchaseOrderVO[] po = null;
	try
	{
	  // Look up Entity Bean reference
	  Context ctx = new InitialContext();
	  PurchaseOrderHome poHome = (PurchaseOrderHome)
	  PortableRemoteObject.narrow(
		ctx.lookup(
			"java:comp/env/BookSamples/PurchaseOrder"), 
		PurchaseOrderHome.class);
	  // --> End of Entity Bean Lookup
		
	  PurchaseOrder poEjb = null;
	  Iterator poIt = null;
	  Collection poC = 
		poHome.findByCustomerId(customerId);
	  if (poC.size() > 0)
	  {
		po = new PurchaseOrderVO[poC.size()];
		int i = 0;
		poIt = poC.iterator();
		while (poIt.hasNext())
		{
			poEjb = (PurchaseOrder)poIt.next();
			po[i] = new PurchaseOrderVO();
			po[i].setCustomerId(poEjb.getCustomerId());
			po[i].setOrderNbr(poEjb.getOrderNbr());
			po[i].setOrderDate(poEjb.getDateCreated());
			po[i].setShipDate(poEjb.getDateShipped());
			
			i++;
		}
	  }
	  
	}
	catch (Throwable t)
	{
		throw new SampleException
			  ( "Error searching PO. cust=" + 
				customerId, t);
	}
	
	return po;
  }

public Session getHibernateSession()
{
	return _hibernateSession;
}

public void setHibernateSession(Session session)
{
	_hibernateSession = session;
}

}
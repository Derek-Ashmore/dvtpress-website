package com.dvt.app.project.vo;

import org.cementj.base.ValueObject;
import java.util.Date;
import java.io.Serializable;

/**
 *  VO representing information about a project.  This 
 *  class is part of the ProjectTrak application.
 *  <p>Copyright:  Delta Vortex Technologies, 2003.
 */
public class ProjectVO 
	extends ValueObject
	implements Serializable, Comparable
{

  public ProjectVO() {}

  public String getProjectName()          
  {
  	return _projectName;
  }
  public void setProjectName(String name)
  {
    if (name == null)  
    {
    	throw new IllegalArgumentException
    			("Null project name not allowed.");
    } 
    if (name.equals(""))  
    {
    	throw new IllegalArgumentException
    			("Blank project name not allowed.");
    } 
    _projectName = name;
  }

  public String[] getProjectBaselineNames() 
  {
  	return _projectBaselines;
  }
  public void setProjectBaselineNames(String[] name)
  {
    _projectBaselines = name;
  }

  public Date getDateCreated()            
  {
  	return _dateCreated;
  }
  public void setDateCreated(Date dateCreated)
  {
    if (dateCreated == null)  
    {
    	throw new IllegalArgumentException
    			("Null dateCreated not allowed.");
    } 
    _dateCreated = dateCreated;
  }

  public Date getDateModified()           
  {
  	return _dateLastModified;
  }
  public void setDateModified(Date dateLastModified)
  {
    if (dateLastModified == null)  
    {
    	throw new IllegalArgumentException
    			("Null dateLastModified not allowed.");
    } 
    _dateLastModified = dateLastModified;
  }

  public Date getProjectStart()           
  {
  	return _projectStart;
  }
  public void setProjectStart(Date start)
  {
    _projectStart = start;
  }

  public Date getProjectEnd()           
  {
  	return _projectEnd;
  }
  public void setProjectEnd(Date end)
  {
    _projectEnd = end;
  }

  public ResourceVO[] getAssignedResources()      
  {
  	return _assignedResources;
  }
  public void setAssignedResources(
  					ResourceVO[] assignedResources)
  {
    if (assignedResources == null)  
    {
    	throw new IllegalArgumentException
    		  ("Null assignedResources not allowed.");
    } 
    _assignedResources = assignedResources;
  }

  public ProjectTaskVO[] getProjectTasks()      
  {
  	return _projectTasks;
  }
  public void setProjectTasks(
  						ProjectTaskVO[] projectTasks)
  {
    if (projectTasks == null)  
    {
    	throw new IllegalArgumentException
    			("Null projectTasks not allowed.");
    } 
    _projectTasks = projectTasks;
  }
  
  public int compareTo(Object obj)
  {
  	int comparator = 0;
  	 if (obj == null)
  	 {
  	 	throw new IllegalArgumentException
  	 		( "Null object not allowed.");
  	 }
	 if (! (obj instanceof ProjectVO) )
	 {
	 	throw new IllegalArgumentException
	 		( "Invalid Object Type: " + 
	 		  obj.getClass().getName());
	 }
	 
	 ProjectVO pvo = (ProjectVO) obj;
	 comparator = _projectName.compareTo(
						pvo._projectName);
     if (comparator == 0)
     {
		comparator = _dateLastModified.compareTo(
						   pvo._dateLastModified);
     }
	 
	 return comparator;
  }

  private String            _projectName = null;
  private String[]          _projectBaselines = null;
  private Date              _dateCreated = null;
  private Date              _dateLastModified = null;
  private ResourceVO[]     _assignedResources = null;
  private ProjectTaskVO[]  _projectTasks = null;
  private Date              _projectStart = null;
  private Date              _projectEnd = null;

}